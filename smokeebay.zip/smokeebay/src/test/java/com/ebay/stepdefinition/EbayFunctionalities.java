package com.ebay.stepdefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import com.ebay.utils.FrameworkUtils;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class EbayFunctionalities {
	public WebDriver driver;

	@Given("^User should be in Home page of ebay$")
	public void user_should_be_in_Home_page_of_ebay() throws Throwable {
		String projectPath = System.getProperty("user.dir");
		System.out.println(projectPath);
		String chromePath = projectPath + "/chromedriver/chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", chromePath);
		/*Initialise the chromedriver and go to ebay shopping site*/
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.ebay.com.au/");

	}

	@When("^User search for shoes item and add to cart$")
	public void user_search_for_shoes_item_and_add_to_cart() throws Throwable {
		driver.findElement(By.id("gh-ac")).clear();
		driver.findElement(By.id("gh-ac")).sendKeys("shoes");
		/*User searches for the shoes and provides specification like color and size*/
		driver.findElement(By.id("gh-btn")).click();
		driver.findElement(By.xpath("//div[@class=\"s-item__image-wrapper\"]//img[1]")).click();
		new Select(driver.findElement(By.xpath("//select[@name=\"Colour\"]"))).selectByIndex(1);
		new Select(driver.findElement(By.xpath("//select[@name=\"Size\"]"))).selectByIndex(1);
        /*Item selected will be added to the cart*/
		driver.findElement(By.xpath("//a[contains(text(),'Add to cart')]")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[@class=\"app-atc-layer__actionRow\"]//a[contains(@class,'viewAllLink')]"))
				.click();

	}

	@When("^User search for bag item and add to cart$")
	public void user_search_for_bag_item_and_add_to_cart() throws Throwable {
		driver.findElement(By.id("gh-ac")).clear();
		driver.findElement(By.id("gh-ac")).sendKeys("bags");
		/*User searches for the bags and provides specification like Style, Qty and color*/
		driver.findElement(By.id("gh-btn")).click();
		driver.findElement(By.xpath("//img[@class='s-item__image-img' and contains(@alt,'bag')][1]")).click();

		if (FrameworkUtils.elementPresent(driver, By.xpath("//select[@name=\"Style\"]"))) {
			new Select(driver.findElement(By.xpath("//select[@name=\"Style\"]"))).selectByIndex(1);
		}
		if (FrameworkUtils.elementPresent(driver, By.xpath("//select[@name=\"Qty\"]"))) {
			new Select(driver.findElement(By.xpath("//select[@name=\"Qty\"]"))).selectByIndex(1);
		}
		if (FrameworkUtils.elementPresent(driver, By.xpath("//select[@name=\"Color\"]"))) {
			new Select(driver.findElement(By.xpath("//select[@name=\"Color\"]"))).selectByIndex(1);
		}
		/*Item selected will be added to the cart*/
		driver.findElement(By.xpath("//a[contains(text(),'Add to cart')]")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[@class=\"app-atc-layer__actionRow\"]//a[contains(@class,'viewAllLink')]"))
				.click();

	}

	@Then("^User should navigate to cart page and validate items$")
	public void user_should_navigate_to_cart_page_and_validate_items() throws Throwable {
		driver.findElement(By.id("gh-cart-i")).click();
		/*Navigate to cart and checks if selected items are added to the cart*/
		Assert.assertTrue(driver.findElement(By.xpath("//span[text()='Items (2)']")).isDisplayed());

	}

	@Then("^User should navigate to checkout page$")
	public void user_should_navigate_to_checkout_page() throws Throwable {
		driver.findElement(By.xpath("//*[text()='Go to checkout']")).click();
		Thread.sleep(3000);
		/*Navigating to checkout page as a guest*/
		driver.findElement(By.xpath("//*[text()=\"Continue as a guest\"]")).click();

		Assert.assertEquals(driver.findElement(By.xpath("//h1[@class=\"page-title\"]")).getText(), "Checkout");

	}

	@Then("^Close browser and application$")
	public void Close_browser_and_application() throws Throwable {
		driver.quit();
	}

}
