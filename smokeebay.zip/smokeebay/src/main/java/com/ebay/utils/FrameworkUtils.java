package com.ebay.utils;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class FrameworkUtils {
	public static boolean elementPresent(WebDriver driver, By by) {
		boolean status = true;
		try {
			driver.findElement(by);
		} catch (Exception e) {
			status = false;
		}
		return status;

	}

}
