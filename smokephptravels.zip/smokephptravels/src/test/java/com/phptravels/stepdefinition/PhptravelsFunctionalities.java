package com.phptravels.stepdefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class PhptravelsFunctionalities {
	public WebDriver driver;

	@Given("^User should be in Home page of phptravels$")
	public void user_should_be_in_Home_page_of_phptravels() throws Throwable {
		String projectPath = System.getProperty("user.dir");
		System.out.println(projectPath);
		String chromePath = projectPath + "/chromedriver/chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", chromePath);
		/*Initialise the chromedriver and go to phptravels site*/
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-notifications");
		driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.get("https://phptravels.com/demo/");
		Thread.sleep(3000);
		driver.navigate().refresh();

	}

	@When("^User navigate to Expedia Hotels Module$")
	public void user_navigate_to_Expedia_Hotels_Module() throws Throwable {

		driver.navigate().to("https://www.phptravels.net/public/expedia/");

	}

	@When("^perform search by entering valid details$")
	public void enter_perform_search_by_entering_valid_details() throws Throwable {
		driver.findElement(By.id("citiesInput")).clear();
		/*Provide valid input details and perform the request search for hotel booking*/
		driver.findElement(By.id("citiesInput")).sendKeys("Sydney, Australia");
		driver.findElement(By.id("citiesInput")).sendKeys(Keys.TAB);
		driver.findElement(By.xpath("(//td[@class=\"day \" and text()='20'])[1]")).click();
		driver.findElement(By.xpath("(//td[@class=\"day \" and text()='23'])[2]")).click();
		Thread.sleep(3000);

		new Actions(driver).click(driver.findElement(By.xpath("//button[contains(text(),'Search')]"))).perform();

	}

	@When("^User should navigate to details page$")
	public void user_should_navigate_to_details_page() throws Throwable {
		new Actions(driver).click(driver.findElement(By.xpath("(//button[text()='Details'])[1]"))).perform();
		Thread.sleep(3000);

	}

	@When("^User should book a hotel as a guest$")
	public void user_should_book_a_hotel_as_a_guest() throws Throwable {

		new Actions(driver).click(driver.findElement(By.xpath("(//span[text()='Book Now'])[1]"))).perform();
		Thread.sleep(3000);
		/*Navigating to checkout page as a guest*/
		new Actions(driver).click(driver.findElement(By.xpath("(//button[text()='Book as a Guest'])[1]"))).perform();
		Thread.sleep(3000);

	}

	@Then("^User should be in Booking Summary page$")
	public void user_should_be_in_Booking_Summary_page() throws Throwable {

		Assert.assertTrue(driver.findElement(By.xpath("//h4[text()='Booking Summary']")).isDisplayed());

	}

	@Then("^Close browser and application$")
	public void close_browser_and_application() throws Throwable {
		driver.quit();
	}

	@When("^User navigate to Amadues Flights Module$")
	public void user_navigate_to_Amadues_Flights_Module() throws Throwable {
		driver.navigate().to("https://www.phptravels.net/public/amadeus/");

	}

	@When("^perform flight search by entering valid details$")
	public void perform_flight_search_by_entering_valid_details() throws Throwable {
		Thread.sleep(3000);
		new Actions(driver).click(driver.findElement(By.xpath("//*[@id=\"s2id_origin\"]/a"))).perform();
		/*Provide valid input details and perform the request search for booking flights*/
		driver.findElement(By.xpath("//*[@id=\"select2-drop\"]/div/input")).sendKeys("HDD");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id=\"select2-drop\"]/div/input")).sendKeys(Keys.TAB);
		Thread.sleep(3000);
		new Actions(driver).click(driver.findElement(By.xpath("//*[@id=\"s2id_destination\"]/a"))).perform();
		driver.findElement(By.xpath("//*[@id=\"select2-drop\"]/div/input")).sendKeys("KOL");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id=\"select2-drop\"]/div/input")).sendKeys(Keys.TAB);
		Thread.sleep(3000);
		new Actions(driver).click(driver.findElement(By.xpath("//*[@id=\"amadeus_search\"]/div/div[1]/div[6]/button")))
				.perform();

	}

	@Then("^User should be in Airlines details page$")
	public void user_should_be_in_Airlines_details_page() throws Throwable {
		Assert.assertTrue(driver.findElement(By.xpath("//*[contains(text(),'Air Lines')]")).isDisplayed());

	}

}