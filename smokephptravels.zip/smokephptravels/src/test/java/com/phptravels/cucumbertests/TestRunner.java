package com.phptravels.cucumbertests;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features = "features", glue = { "com.phptravels.stepdefinition" },dryRun = false, tags = {"@functionality"}, plugin = {"pretty", "html:target/phptravels.report" })
public class TestRunner {

}
