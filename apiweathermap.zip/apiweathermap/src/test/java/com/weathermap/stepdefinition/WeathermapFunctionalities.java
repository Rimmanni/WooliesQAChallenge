package com.weathermap.stepdefinition;

import static io.restassured.RestAssured.given;

import java.util.Calendar;
import java.util.TimeZone;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.response.Response;

public class WeathermapFunctionalities {
	String cityname;
	Response response;
	String tempinfo;
	int retrivalvalue = 0;
	int thursdayDayCount = 5;
	int daysOfWeek = 7;
	int thursdayIndex = 0;

	@Given("^I like to holiday in Sydney$")
	public void i_like_to_holiday_in_Sydney() throws Throwable {
		cityname = "Sydney";
	}

	@Given("^I only like to holiday on Thursdays$")
	public void i_only_like_to_holiday_on_Thursdays() throws Throwable {
		Calendar calendar = Calendar.getInstance(TimeZone.getDefault());
		int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
		System.out.println("Current Day of Week is: " + dayOfWeek);
		if (dayOfWeek < thursdayDayCount) {
			retrivalvalue = thursdayDayCount - dayOfWeek;
		} else {
			retrivalvalue = (daysOfWeek - dayOfWeek) + thursdayDayCount;
		}
		thursdayIndex = retrivalvalue;
		System.out.println("thursday index :" + thursdayIndex);

	}

	@When("^I look up the weather forecast$")
	public void i_look_up_the_weather_forecast() throws Throwable {
		response = given().header("Content-Type", "application/json").queryParam("q", cityname).queryParam("cnt", "7")
				.queryParam("APPID", "d913c1b34fa73f2ffe884ba13f1f2b10").when()
				.get("http://api.openweathermap.org/data/2.5/find").then().extract().response();
		System.out.println("responce body :" + response.getBody().asString());

	}

	@Then("^I receive the weather forecast$")
	public void i_receive_the_weather_forecast() throws Throwable {

		tempinfo = response.jsonPath().getString("list[" + thursdayIndex + "].main.temp");
		System.out.println("tempinfo :" + tempinfo);

	}

	@Then("^The temperature is warmer than (\\d+) degrees$")
	public void the_temperature_is_warmer_than_degrees(int arg1) throws Throwable {
		if (Float.parseFloat(tempinfo) > 10) {
			System.out.println("Thursday weather returned is > 10 degrees");
		} else {
			System.out.println("Thursday weather returned is > 10 degrees");
		}

	}

}
